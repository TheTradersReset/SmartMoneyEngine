from src.core.data_loader import DataLoader

from src.models.market_data import MarketData

from src.indicators.ema import EMA

loader = DataLoader()

df = loader.load_csv(
    "data/sample/nifty_sample.csv"
)

market = MarketData(df)

EMA(20).calculate(market)

print()

print(
    market.head()
)