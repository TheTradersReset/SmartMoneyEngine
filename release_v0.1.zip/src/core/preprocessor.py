"""
Data preparation before indicators.
"""