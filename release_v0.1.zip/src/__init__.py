"""
Smart Money Engine Package
"""