from src.indicators.base_indicator import BaseIndicator
from src.core.logger import logger


class EMA(BaseIndicator):
    """
    Exponential Moving Average Indicator.
    """

    def __init__(self, period: int):

        super().__init__()

        if period <= 0:
            raise ValueError(
                "EMA period must be greater than zero."
            )

        self.period = period
        self.column_name = f"EMA_{period}"

    def calculate(self, market):

        logger.info(
            f"Calculating EMA-{self.period}..."
        )

        if not market.has_column("Close"):
            raise ValueError(
                "Close column not found."
            )

        # Avoid duplicate calculation

        if market.has_column(self.column_name):

            logger.warning(
                f"{self.column_name} already exists."
            )

            return market

        ema = (
            market
            .get_column("Close")
            .ewm(
                span=self.period,
                adjust=False
            )
            .mean()
        )

        market.add_column(
            self.column_name,
            ema
        )

        logger.info(
            f"{self.column_name} calculated successfully."
        )

        return market